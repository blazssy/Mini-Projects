from flask import Flask, jsonify, request, render_template, redirect, url_for
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///todo.db'
db = SQLAlchemy(app)

# Define the Todo model with Usn, Name, Skills, and Extra fields
class Todo(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    Usn = db.Column(db.String(50), nullable=False)
    Name = db.Column(db.String(50), nullable=False)
    Skills = db.Column(db.String(1000), nullable=True)
    Extra = db.Column(db.String(100), nullable=True)

# Initialize the database
with app.app_context():
    db.create_all()

# Route to view all tasks
@app.route('/', methods=['GET'])
def index():
    data = Todo.query.all()
    context = []
    for dt in data:
        dd = {"Usn": dt.Usn, "Name": dt.Name, "Skills": dt.Skills, "Extra": dt.Extra, "id": dt.id}
        context.append(dd)
    return render_template('todo.html', todo=context)

# Route to show the add task form
@app.route('/add-members')
def add_task():
    return render_template('add-task.html')

# Route to submit a new task
@app.route('/submit', methods=['POST'])
def create_user():
    Usn = request.form['Usn']
    Name = request.form['Name']
    Skills = request.form['Skills']
    Extra = request.form['Extra']

    # Create a new Todo item without the need for an 'id' field
    new_task = Todo(Usn=Usn, Name=Name, Skills=Skills, Extra=Extra)
    db.session.add(new_task)
    db.session.commit()

    return redirect(url_for('index'))  # Redirect to the main page after adding a new task

# Route to delete a task by ID
@app.route('/delete/<int:id>', methods=['GET', 'DELETE'])
def delete_user(id):
    task = Todo.query.get(id)
    if not task:
        return jsonify({'message': 'task not found'}), 404
    db.session.delete(task)
    db.session.commit()
    return jsonify({'message': 'task deleted successfully'}), 200

# Route to update a task by ID
@app.route('/update_task/<int:id>', methods=['GET', 'POST'])
def update_task(id):
    task = Todo.query.get_or_404(id)
    if request.method == 'POST':
        task.Usn = request.form['Usn']  # Now this will be present in the form data
        task.Name = request.form['Name']
        task.Skills = request.form['Skills']
        task.Extra = request.form['Extra']
        db.session.commit()
        return redirect(url_for('index'))  # Redirect to the list of tasks after updating
    return render_template('update.html', task=task)
if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5007, debug=True)
